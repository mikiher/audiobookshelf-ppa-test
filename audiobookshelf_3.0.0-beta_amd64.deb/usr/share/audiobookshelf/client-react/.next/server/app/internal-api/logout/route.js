var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/logout/route.js")
R.c("server/chunks/[root-of-the-server]__1fxagmkhll--b._.js")
R.c("server/chunks/_1xz7gu7v_796w._.js")
R.c("server/chunks/_0f6evqg1se113._.js")
R.c("server/chunks/[root-of-the-server]__197yn12-25jgd._.js")
R.c("server/chunks/_next-internal_server_app_internal-api_logout_route_actions_1r_5gaj3cw43k.js")
R.m(69491)
module.exports=R.m(69491).exports
