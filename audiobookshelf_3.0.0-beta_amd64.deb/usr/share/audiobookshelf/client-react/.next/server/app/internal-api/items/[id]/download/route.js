var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/items/[id]/download/route.js")
R.c("server/chunks/[root-of-the-server]__1fxagmkhll--b._.js")
R.c("server/chunks/_1bytzlcpes-4z._.js")
R.c("server/chunks/[root-of-the-server]__197yn12-25jgd._.js")
R.c("server/chunks/_0f6evqg1se113._.js")
R.c("server/chunks/src_lib_13lgmxjz-twaj._.js")
R.c("server/chunks/1oeh_server_app_internal-api_items_[id]_download_route_actions_0fzlmnrk8kr-m.js")
R.m(39247)
module.exports=R.m(39247).exports
