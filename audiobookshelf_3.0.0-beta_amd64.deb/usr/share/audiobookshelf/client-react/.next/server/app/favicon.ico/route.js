var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]__0l0ye5i8pzj91._.js")
R.c("server/chunks/[root-of-the-server]__1u20s0slvrdsh._.js")
R.c("server/chunks/_1rx4o444o7bqk._.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_0g2jjlssn1kss.js")
R.m(51660)
module.exports=R.m(51660).exports
