module.exports=[6944,(e,o,d)=>{}];

//# sourceMappingURL=1jng_app_internal-api_items_%5Bid%5D_file_%5BfileId%5D_media_route_actions_0oiw83trne62_.js.map