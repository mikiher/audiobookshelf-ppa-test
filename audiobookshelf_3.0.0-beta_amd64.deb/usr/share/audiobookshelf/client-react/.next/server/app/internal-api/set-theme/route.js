var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/set-theme/route.js")
R.c("server/chunks/[root-of-the-server]__0xmry0oa37d15._.js")
R.c("server/chunks/[root-of-the-server]__1u20s0slvrdsh._.js")
R.c("server/chunks/_10o1keng7t8-i._.js")
R.c("server/chunks/_next-internal_server_app_internal-api_set-theme_route_actions_0ibiyriitk72j.js")
R.m(79027)
module.exports=R.m(79027).exports
