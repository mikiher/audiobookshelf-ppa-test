module.exports=[70002,(e,o,p)=>{o.exports={}}];

//# sourceMappingURL=src_locales_lv_json_%5Bjson%5D_cjs_04f88b22wkc9n._.js.map