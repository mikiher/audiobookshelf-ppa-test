var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/items/[id]/ebook/route.js")
R.c("server/chunks/[root-of-the-server]__1fxagmkhll--b._.js")
R.c("server/chunks/_1m9pice8y31ha._.js")
R.c("server/chunks/[root-of-the-server]__197yn12-25jgd._.js")
R.c("server/chunks/_0f6evqg1se113._.js")
R.c("server/chunks/src_lib_13lgmxjz-twaj._.js")
R.c("server/chunks/1oeh_server_app_internal-api_items_[id]_ebook_route_actions_0se3uddxf3u9b.js")
R.m(219)
module.exports=R.m(219).exports
