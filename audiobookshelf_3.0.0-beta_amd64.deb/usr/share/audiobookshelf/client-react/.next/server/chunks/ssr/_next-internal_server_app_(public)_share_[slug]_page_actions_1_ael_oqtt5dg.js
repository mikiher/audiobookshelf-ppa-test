module.exports=[35479,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28public%29_share_%5Bslug%5D_page_actions_1_ael_oqtt5dg.js.map