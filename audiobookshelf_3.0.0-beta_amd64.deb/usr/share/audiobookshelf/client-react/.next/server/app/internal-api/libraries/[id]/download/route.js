var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/libraries/[id]/download/route.js")
R.c("server/chunks/[root-of-the-server]__1fxagmkhll--b._.js")
R.c("server/chunks/_1mbj8batfpx1c._.js")
R.c("server/chunks/[root-of-the-server]__197yn12-25jgd._.js")
R.c("server/chunks/_0f6evqg1se113._.js")
R.c("server/chunks/src_lib_13lgmxjz-twaj._.js")
R.c("server/chunks/1oeh_server_app_internal-api_libraries_[id]_download_route_actions_1ji55mnqoyzgz.js")
R.m(13954)
module.exports=R.m(13954).exports
