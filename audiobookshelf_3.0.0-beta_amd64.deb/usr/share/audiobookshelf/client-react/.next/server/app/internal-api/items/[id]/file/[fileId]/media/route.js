var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/items/[id]/file/[fileId]/media/route.js")
R.c("server/chunks/[root-of-the-server]__1fxagmkhll--b._.js")
R.c("server/chunks/_1cmctr38n4usx._.js")
R.c("server/chunks/[root-of-the-server]__197yn12-25jgd._.js")
R.c("server/chunks/_0f6evqg1se113._.js")
R.c("server/chunks/src_lib_1ye72zhb568pr._.js")
R.c("server/chunks/1jng_app_internal-api_items_[id]_file_[fileId]_media_route_actions_0oiw83trne62_.js")
R.m(4659)
module.exports=R.m(4659).exports
