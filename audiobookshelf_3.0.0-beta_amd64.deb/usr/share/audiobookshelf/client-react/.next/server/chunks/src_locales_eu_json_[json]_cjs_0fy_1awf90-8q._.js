module.exports=[89081,(e,o,p)=>{o.exports={}}];

//# sourceMappingURL=src_locales_eu_json_%5Bjson%5D_cjs_0fy_1awf90-8q._.js.map