module.exports=[17071,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_internal-api_items_upload_route_actions_01a1cuxz5bywo.js.map