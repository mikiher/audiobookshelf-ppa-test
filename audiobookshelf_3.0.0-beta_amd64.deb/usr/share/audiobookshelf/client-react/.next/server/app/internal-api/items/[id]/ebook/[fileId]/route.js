var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/items/[id]/ebook/[fileId]/route.js")
R.c("server/chunks/[root-of-the-server]__1fxagmkhll--b._.js")
R.c("server/chunks/_04f6442tnq5bf._.js")
R.c("server/chunks/[root-of-the-server]__197yn12-25jgd._.js")
R.c("server/chunks/_0f6evqg1se113._.js")
R.c("server/chunks/src_lib_13lgmxjz-twaj._.js")
R.c("server/chunks/1oeh_server_app_internal-api_items_[id]_ebook_[fileId]_route_actions_0ecusyh5rt_zn.js")
R.m(14978)
module.exports=R.m(14978).exports
