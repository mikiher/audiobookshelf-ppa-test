var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/items/[id]/file/[fileId]/route.js")
R.c("server/chunks/[root-of-the-server]__1fxagmkhll--b._.js")
R.c("server/chunks/_0iqvrisi_d474._.js")
R.c("server/chunks/[root-of-the-server]__197yn12-25jgd._.js")
R.c("server/chunks/_0f6evqg1se113._.js")
R.c("server/chunks/src_lib_13lgmxjz-twaj._.js")
R.c("server/chunks/1oeh_server_app_internal-api_items_[id]_file_[fileId]_route_actions_0qr2bzikpsvgv.js")
R.m(70305)
module.exports=R.m(70305).exports
