var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[externals]__0l0ye5i8pzj91._.js")
R.c("server/chunks/[root-of-the-server]__1u20s0slvrdsh._.js")
R.c("server/chunks/_02icavzhihho0._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_15vc_89wprgh5.js")
R.m(75846)
module.exports=R.m(75846).exports
