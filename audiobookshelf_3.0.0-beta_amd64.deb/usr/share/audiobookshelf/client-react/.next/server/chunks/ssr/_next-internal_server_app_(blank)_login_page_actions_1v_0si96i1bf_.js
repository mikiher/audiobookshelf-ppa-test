module.exports=[9525,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28blank%29_login_page_actions_1v_0si96i1bf_.js.map