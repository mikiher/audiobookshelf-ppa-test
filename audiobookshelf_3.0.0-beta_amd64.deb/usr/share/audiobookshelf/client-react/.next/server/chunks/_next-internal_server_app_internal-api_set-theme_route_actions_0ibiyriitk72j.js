module.exports=[99850,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_internal-api_set-theme_route_actions_0ibiyriitk72j.js.map