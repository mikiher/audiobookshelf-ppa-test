module.exports=[7668,r=>{"use strict";r.s(["E",0,function(r){return r?`/library/${r}`:"/library"},"m",0,function(r){return"admin"===r||"root"===r}])}];

//# sourceMappingURL=src_lib_userPermissions_ts_0xf58v4tf-f75._.js.map