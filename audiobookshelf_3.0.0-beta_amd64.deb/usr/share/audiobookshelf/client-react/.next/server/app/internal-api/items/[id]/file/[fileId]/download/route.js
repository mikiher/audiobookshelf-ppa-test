var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/items/[id]/file/[fileId]/download/route.js")
R.c("server/chunks/[root-of-the-server]__1fxagmkhll--b._.js")
R.c("server/chunks/_13-4j6akz61qi._.js")
R.c("server/chunks/[root-of-the-server]__197yn12-25jgd._.js")
R.c("server/chunks/_0f6evqg1se113._.js")
R.c("server/chunks/src_lib_13lgmxjz-twaj._.js")
R.c("server/chunks/1jng_app_internal-api_items_[id]_file_[fileId]_download_route_actions_017wmpl9llgvb.js")
R.m(17593)
module.exports=R.m(17593).exports
