module.exports=[27084,(e,o,d)=>{}];

//# sourceMappingURL=1jng_app_internal-api_items_%5Bid%5D_file_%5BfileId%5D_download_route_actions_017wmpl9llgvb.js.map