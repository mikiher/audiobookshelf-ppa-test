var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/refresh/route.js")
R.c("server/chunks/src_lib_userPermissions_ts_0xf58v4tf-f75._.js")
R.c("server/chunks/[root-of-the-server]__1fxagmkhll--b._.js")
R.c("server/chunks/[root-of-the-server]__197yn12-25jgd._.js")
R.c("server/chunks/_0f6evqg1se113._.js")
R.c("server/chunks/_138cwq28n_hfd._.js")
R.c("server/chunks/_next-internal_server_app_internal-api_refresh_route_actions_1pa8y6w-_iwc9.js")
R.m(6230)
module.exports=R.m(6230).exports
