var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/internal-api/set-language/route.js")
R.c("server/chunks/[root-of-the-server]__0xmry0oa37d15._.js")
R.c("server/chunks/[root-of-the-server]__1u20s0slvrdsh._.js")
R.c("server/chunks/_0e1bppb4kff0r._.js")
R.c("server/chunks/_next-internal_server_app_internal-api_set-language_route_actions_0_inqh9rckvgx.js")
R.m(47259)
module.exports=R.m(47259).exports
