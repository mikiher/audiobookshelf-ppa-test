module.exports=[70278,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_internal-api_set-language_route_actions_0_inqh9rckvgx.js.map