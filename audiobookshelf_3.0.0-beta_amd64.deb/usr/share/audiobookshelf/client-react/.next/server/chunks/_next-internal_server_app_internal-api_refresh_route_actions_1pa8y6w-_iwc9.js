module.exports=[62072,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_internal-api_refresh_route_actions_1pa8y6w-_iwc9.js.map