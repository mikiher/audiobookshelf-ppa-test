module.exports=[13605,(e,o,p)=>{o.exports={}}];

//# sourceMappingURL=src_locales_uz_json_%5Bjson%5D_cjs_1rpaeua9oe7cb._.js.map